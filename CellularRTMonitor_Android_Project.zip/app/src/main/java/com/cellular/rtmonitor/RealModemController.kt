package com.cellular.rtmonitor

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.telephony.TelephonyManager
import androidx.annotation.RequiresApi

class RealModemController(private val context: Context) {

    private val telephonyManager =
        context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    @RequiresApi(Build.VERSION_CODES.S)
    fun setRealNetworkTypeLock(ratMode: String) {
        val networkTypeBitmask: Long = when (ratMode) {
            "5G" -> TelephonyManager.NETWORK_TYPE_BITMASK_NR
            "4G" -> TelephonyManager.NETWORK_TYPE_BITMASK_LTE
            "3G" -> (TelephonyManager.NETWORK_TYPE_BITMASK_UMTS or
                     TelephonyManager.NETWORK_TYPE_BITMASK_HSDPA or
                     TelephonyManager.NETWORK_TYPE_BITMASK_HSUPA or
                     TelephonyManager.NETWORK_TYPE_BITMASK_HSPA or
                     TelephonyManager.NETWORK_TYPE_BITMASK_HSPAP)
            "2G" -> (TelephonyManager.NETWORK_TYPE_BITMASK_GSM or
                     TelephonyManager.NETWORK_TYPE_BITMASK_GPRS or
                     TelephonyManager.NETWORK_TYPE_BITMASK_EDGE)
            else -> (TelephonyManager.NETWORK_TYPE_BITMASK_NR or
                     TelephonyManager.NETWORK_TYPE_BITMASK_LTE or
                     TelephonyManager.NETWORK_TYPE_BITMASK_UMTS or
                     TelephonyManager.NETWORK_TYPE_BITMASK_GSM)
        }

        try {
            telephonyManager.setAllowedNetworkTypesForReason(
                TelephonyManager.ALLOWED_NETWORK_TYPES_REASON_USER,
                networkTypeBitmask
            )
        } catch (e: SecurityException) {
            openDeviceNetworkSettings()
        }
    }

    fun setRealAirplaneMode(enable: Boolean) {
        val state = if (enable) 1 else 0
        try {
            Settings.Global.putInt(
                context.contentResolver,
                Settings.Global.AIRPLANE_MODE_ON,
                state
            )
            val intent = Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED).apply {
                putExtra("state", enable)
            }
            context.sendBroadcast(intent)
        } catch (e: SecurityException) {
            val intent = Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    fun openDeviceNetworkSettings() {
        val intent = Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
