package com.cellular.rtmonitor

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var telemetryEngine: ModemTelemetryEngine
    private lateinit var modemController: RealModemController
    private val pollingHandler = Handler(Looper.getMainLooper())
    private val SHIZUKU_CODE = 1001

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_CODE && grantResult == PackageManager.PERMISSION_GRANTED) {
            // Shizuku permission granted
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineLocationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val phoneStateGranted = permissions[Manifest.permission.READ_PHONE_STATE] ?: false
        if (fineLocationGranted && phoneStateGranted) {
            startRealModemStream()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        modemController = RealModemController(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(WebAppInterface(), "AndroidModem")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)

        telemetryEngine = ModemTelemetryEngine(this) { jsonPayload ->
            val jsCall = "if (window.onRealModemData) { window.onRealModemData($jsonPayload); }"
            webView.evaluateJavascript(jsCall, null)
        }

        checkAndRequestPermissions()
        requestShizukuPermissionIfNeeded()
    }

    private fun requestShizukuPermissionIfNeeded() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(SHIZUKU_CODE)
                }
            }
        } catch (e: Exception) {
            // Shizuku service not running
        }
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun setRatMode(ratMode: String) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                modemController.setRealNetworkTypeLock(ratMode)
            } else {
                modemController.openDeviceNetworkSettings()
            }
        }

        @JavascriptInterface
        fun setAirplaneMode(enable: Boolean) {
            modemController.setRealAirplaneMode(enable)
        }
    }

    private fun checkAndRequestPermissions() {
        val needed = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isEmpty()) {
            startRealModemStream()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startRealModemStream() {
        telemetryEngine.startListening()

        val pollRunnable = object : Runnable {
            override fun run() {
                telemetryEngine.collectAndEmitTelemetry()
                pollingHandler.postDelayed(this, 1000)
            }
        }
        pollingHandler.post(pollRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        pollingHandler.removeCallbacksAndMessages(null)
    }
}
